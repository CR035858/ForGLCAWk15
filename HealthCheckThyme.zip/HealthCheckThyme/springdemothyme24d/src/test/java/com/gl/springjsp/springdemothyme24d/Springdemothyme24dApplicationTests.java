package com.gl.springjsp.springdemothyme24d;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springdemothyme24dApplicationTests {

	@Test
	void contextLoads() {
	}

}

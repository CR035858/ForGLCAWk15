package com.gl.springjsp.springdemothyme24d;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springdemothyme24dApplication {

	public static void main(String[] args) {
		SpringApplication.run(Springdemothyme24dApplication.class, args);
	}

}
